
package Entidades;

public class usuario {
   // Atributos que representan los datos de un usuario en la base de datos
    private String Nombre;
    private String Email;
    private String Contra;
    private String Rol;
    private boolean Activo;
    
    // Constructor para inicializar los atributos

    public usuario(String Nombre, String Email, String Contra, String Rol, boolean Activo) {
        this.Nombre = Nombre;
        this.Email = Email;
        this.Contra = Contra;
        this.Rol = Rol;
        this.Activo = Activo;
    }

    public usuario() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    // Métodos getter para obtener los valores de los atributos

    public String getNombre() {
        return Nombre;
    }

    public String getEmail() {
        return Email;
    }

    public String getContra() {
        return Contra;
    }

    public String getRol() {
        return Rol;
    }

    public boolean isActivo() {
        return Activo;
    }
    
    // Métodos setter para modificar los valores de los atributos

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setContra(String Contra) {
        this.Contra = Contra;
    }

    public void setRol(String Rol) {
        this.Rol = Rol;
    }

    public void setActivo(boolean Activo) {
        this.Activo = Activo;
    }
    
    // Método toString para representar el objeto como una cadena de texto

    @Override
    public String toString() {
        return "usuario{" + "Nombre=" + Nombre + ", Email=" + Email + ", Contra=" + Contra + ", Rol=" + Rol + ", Activo=" + Activo + '}';
    }

    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
}
